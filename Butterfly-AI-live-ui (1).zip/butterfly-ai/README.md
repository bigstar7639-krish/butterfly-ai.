# Butterfly AI — Android + Website starter

A ChatGPT-inspired personal assistant starter with:
- Responsive web interface and Android wrapper (Capacitor)
- AI chat through a server-side OpenAI-compatible API
- Multiple conversations saved locally in the browser/device
- Custom assistant instructions
- Text/code/CSV/Markdown/JSON file attachments (content is added to chat)
- Browser speech-to-text and read-aloud (where supported)
- Image generation endpoint
- Optional web search (Tavily)
- Five live color themes (Midnight, Aurora, Ocean, Sunset, Rose) with animated ambient glow effects and an effects toggle\n- Light/dark theme and Markdown export

> This is a working starter project, not a hosted service. You supply provider API keys and deploy/run it.

## 1. Requirements
- Node.js 20+ and npm
- An API key for your chosen OpenAI-compatible provider
- Android Studio + Android SDK only if you want to compile/install the Android app

## 2. Run locally (website + API)
```bash
npm install
cp .env.example .env
```
Edit `.env` and set `OPENAI_API_KEY`. Then:
```bash
npm run dev
```
Open **http://localhost:5173**. The API runs on port 8787.

If using a provider-compatible endpoint, set `OPENAI_BASE_URL` and `OPENAI_MODEL` in `.env`. The backend expects a `/chat/completions` endpoint and an `/images/generations` endpoint for image generation.

## 3. Build the Android app
From this project folder:
```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```
Android Studio opens the native wrapper. Select a device/emulator and press Run.
After frontend changes, run `npm run android:sync` again.

**API URL on Android:** the Capacitor app needs to reach your backend. For emulator testing, set `VITE_API_URL` to `http://10.0.2.2:8787` before building (Android emulator maps `10.0.2.2` to your computer). For a physical phone, use your computer's LAN IP, e.g. `http://192.168.1.20:8787`, and ensure both devices are on the same network. For production, use HTTPS and set `VITE_API_URL=https://your-api.example.com` before `npm run build` and `npx cap sync android`.

To set an API URL in a local build, create `.env.local`:
```env
VITE_API_URL=http://10.0.2.2:8787
```
Vite variables are baked into the frontend at build time. Never put secret keys in `VITE_*` variables.

## 4. Deploy as a website
- Build frontend: `npm run build`
- Deploy the `dist/` folder to a static host.
- Deploy `server/` as a Node service with the same environment variables.
- Configure `VITE_API_URL` at build time to point to the deployed HTTPS API.
- If frontend and backend share one Node deployment, run `npm run build` then `npm start`; the Express server serves `dist/`.

## 5. Optional web search
Set `TAVILY_API_KEY` in `.env` to enable Web search. Without it, the UI will show a setup message.

## 6. Important security notes
- Keep provider API keys in the backend `.env` or host secrets. Do not commit `.env`.
- Add authentication, rate limiting, usage limits, and abuse protection before making a public app. This starter does not include user accounts or cloud-synced chats.
- Conversations/settings are stored in localStorage on each browser/device; they are not shared between web and Android and can be cleared by clearing app/site data.
- Text files up to 2 MB are read into the prompt. Non-text files are listed but not parsed in this starter.
- Browser microphone and speech synthesis availability depends on browser/device permissions and implementation.
- Image generation and web search may incur provider charges. Check your provider's pricing and policies.

## 7. Troubleshooting
- **AI not configured:** check `.env`, then restart the server.
- **CORS/network issue:** use the correct `VITE_API_URL`; for Android emulator use `10.0.2.2`, not `localhost`.
- **Android build:** install Android Studio and its SDK/platform tools, then sync again.
- **No image generation:** confirm your provider supports the configured image model and endpoint.
